module RKimex

using LinearAlgebra

# IMEXRKstabmat returns the coefficent matrix R of the one-step map xm+1 = R xm that results from solving u' = Nu + Su where N,S \in \mathbb{R}^d with step-size dt with the r-stage IMEX RK method with method coefficients A,Ahat,b,bhat
function IMEXRKstabmat(N,S,d,dt,A,Ahat,b,bhat,r)
  M = zeros(r,d,d)*1im;
  Id = zeros(d,d)*1im+I;
  M[1,1:d,1:d] = Id[1:d,1:d];
  temp  = zeros(d,d)*1im;
  temp[:,:] =  M[1,:,:];
  R = I+(b[1]*N + bhat[1]*S)*temp[:,:];
  for j = 2:r
  summ = zeros(d,d)*1im + I;
  for l=1:j-1
    temp[:,:] =  M[l,:,:];
    summ = summ+ (A[j,l]*N + Ahat[j,l]*S)*temp[:,:];
  end
    M[j,1:d,1:d] = inv(I-Ahat[j,j]*S)*summ;
    temp[:,:] = M[j,:,:];
    R = R+(b[j]*N + bhat[j]*S)*temp[:,:];
  end
  return R
end


# amplication_factor - user defined returns the "amplication factor" ; Generally modulus of the maximum modulus eigenvalue, depends on the structure of the equations being solved.
function amplification_factor(R,d,par)
  if par == 1 # then use classic 1D test equation amp factor
    EE = abs(R[1,1]);
  elseif par == 2 # then use the Lock, Wood, Weller amp factor
    EE=eigvals(R);
    e=zeros(d)*1im;
    for j=1:d
      e[j] = EE[j];
    end
    E = 0;
    for j=1:d-1
      if abs(e[j]-1) < 1e-13
        E = abs(e[j+1]);
      else
        E = abs(e[1]);
      end
    end
    EE = norm(EE,Inf);
  end
 # return E;
   return EE;
end

end
