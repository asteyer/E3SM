# this driver file produces a plot of the stability region of an IMEX RK method
# based upon a linear test equation defined by the nonstiff (N) and stiff (S) 
# coefficient matrices specified by the user

using Pkg
using LinearAlgebra
using PyPlot
include("get_butcher_tableau.jl")
include("RKimex_stab_functions.jl")

# specify the method, set get_butcher_tableau.jl
n = 31;
(A,Ahat,b,bhat,c,chat,r) =  get_butcher_tableau(n);


# specify the dimension and coefficient matrices of the test problem
# type = 2 is the Lock, Wood, and Weller QJR Met. Soc. 2014 paper test equation
 type = 2 ; d=3; N = 1im*[0 0 1; 0 0 0 ; 1 0 0 ]; S = 1im*[0 0 0 ; 0 0 1 ; 0 1 0];

# type = 1 is the standard linear test equation
# type = 1; d = 1; N = 1im; S = 1im;
#

# this contour function plots the test equation over a variety of 
# wave numbers, x = dt*kx, y = dt*kx, kx, ky are horiz. and vert.
# wave numbers for a HEVI partitioned atmosphere.
function fcontour(x,y)
  R = RKimex.IMEXRKstabmat(x*N,y*S,d,1,A,Ahat,b,bhat,r);
  # par = 1, classic 1D test eq amp factor; par = 2, Lock, Wood, Weller amp factor
  E = RKimex.amplification_factor(R,d,type);
  # sorting regions into distinct numbers for easier plotting
  if E <= 1+1e-10
   return .99;
  elseif 1+1e-10 < E <= 1+1e-5
   return 2
  elseif 1+1e-5 < E <= 1+1e-3
   return 3
  elseif 1+1e-3 < E <= 1+1e-1
   return 4
  elseif E > 1+1e-1
   return 5
  end
end

# The remaining part of the code plots the stability region
# xlength = horizontal window size
xlength = 5.25;
# ylength = vertical window size
ylength = 50;
# xend and yend are the number of horizontal and vertical sample points in the contour plot
xend = 100;
yend = 100;
dx = xlength/xend;
dy = ylength/yend;
x = reshape(range(0,step=dx,length=xend),xend,1);
y = reshape(range(0,step=dy,length = yend),yend,1);
x = range(0,step=dx,length = xend);
y = range(0,step=dy,length = yend);
Z = zeros(xend,yend); Z2 = zeros(xend,yend);
for i=1:xend
  for j=1:yend
    Z[i,j] = fcontour(x[i],y[j]);
  end
end
# plotting stability region
PyPlot.figure()
cp = plt.contourf(x, y, Z',levels=[1,2,3,4,5],cmap=plt.cm.YlGnBu,fontsize=24);
cb = PyPlot.colorbar(cp);
cp.ax.tick_params(labelsize=16)
cb.set_ticklabels(["1","1+1E-5","1+1E-3","1E-1"])
cb.ax.tick_params(labelsize=16)
PyPlot.show()
println("finished")
