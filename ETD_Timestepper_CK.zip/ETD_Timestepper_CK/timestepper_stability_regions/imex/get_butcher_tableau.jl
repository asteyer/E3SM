# this function returns the double Butcher tableau of a method (indexed by n)
# returns A,Ahat,b,bhat,c,chat, and r.  Users are invited to input their own 
# methods or modify the methods herein.
function get_butcher_tableau(n)

  if n == -1
   # c2 = 1;
   # A = [0 0 ; c2 0 ]; b = [1-1/(2*c2) 1/(2*c2)]'; c = A*ones(2,1);
  #  A = [0 0 0 ; 1/2 0 0 ; -1 2 0]; b = [2 -4 3]'; 
    c2 = .5; 
    A = [0 0 0 ; c2 0 0 ; 1-1/c2 1/c2 0]; b = [0 0 1]';
    c = A*ones(3,1);
    Ahat= A; bhat = b; chat = c;
    r = 3;
##################################################################################
############################## NON-IMKG methods #################################
##################################################################################      
  elseif n == 1 # ARS232
    gamma = 1. -1/sqrt(2);
    delta = -2*sqrt(2)/3
    A=[0 0 0 ; gamma 0 0. ; delta 1.0-delta 0];
    b=[0 ; 1-gamma ; gamma];
    c = [0. ; gamma ; 1];
    Ahat = [0 0 0 ; 0 gamma 0. ; 0 1-gamma gamma];
    bhat=[0 ; 1-gamma ; gamma ];
    chat = [0 ; gamma ; 1 ];
    r = 3;
##################################################################################
  elseif n == 2 # ARS343
    gamma = 0.4358665215084590;
    a42 = 0.5529291480359398;
    a43 = a42;
    a41 = 1.0-a42-a43;
    a31 = a42*(2. -9. *gamma+3. *gamma^2)*0.5+a43*0.25*(11. -42. *gamma+15. *gamma^2)-3.5   +13*gamma-4.5*gamma^2;
    a32 = a42*0.5*(-2. +9. *gamma-3. *gamma^2) + a43*(-11. +42. *gamma-15. *gamma^2)*0.25+4. -12.5*gamma+4.5*gamma^2;
    b1=-1.5*gamma^2 + 4. *gamma-0.25;
    b2=1.5*gamma^2-5. *gamma+1.25;
    A = [0. 0. 0. 0. ; gamma 0. 0. 0. ; a31 a32 0. 0. ; a41 a42 a43 0.];
    b = [0. ; b1 ; b2 ; gamma];
    c = [0. ; gamma ; 0.5*(1. +gamma) ; 1.];
    Ahat = [0. 0. 0. 0. ; 0. gamma 0. 0. ; 0. 0.5*(1. -gamma) gamma 0. ; 0. b1 b2 gamma];
    bhat = [0. ; b1 ; b2 ; gamma];
    chat = [0. ; gamma ; 0.5*(1. +gamma) ; 1.];
    r = 4;
##################################################################################
  elseif n == 3 #ARS443
    A = [0. 0. 0. 0. 0.; 0.5 0. 0. 0. 0. ; 11. /18. 1. /18. 0. 0. 0. ; 5. /6. -5. /6. 0.5 0. 0. ; 0.25 7. /4. 0.75 -7. /4. 0.];
    b = [0.25 ; 7. /4.; 3. /4. ; -7. /4.; 0.];
    c = [0. ;0.5 ;2. /3.; 0.5; 1.];
    Ahat=[0. 0. 0. 0. 0. ; 0. 0.5 0. 0. 0. ; 0. 1. /6. 0.5 0. 0. ; 0. -0.5 0.5 0.5 0. ; 0. 1.5 -1.5 0.5 0.5];
    bhat = [0. ;1.5; -1.5; 0.5; 0.5];
    chat = [0. 0.5 2. /3. 0.5 1.];
    r = 5;
##################################################################################
  elseif n == 4 # ARK2 / NUMA method
    r = 3;
    A    = [0 0 0 ; 2-sqrt(2) 0 0 ; 1-(3+2*sqrt(2))/6 (3+2*sqrt(2))/6 0 ];
    Ahat = [0 0 0 ; 1-1/sqrt(2) 1-1/sqrt(2) 0 ; 1/(2*sqrt(2)) 1/(2*sqrt(2)) 1-1/sqrt(2)];
    b    = [1/(2*sqrt(2)) 1/(2*sqrt(2)) 1-1/sqrt(2)];
    bhat = b;
    c = A*ones(3,1);
    chat = Ahat*ones(3,1);
##################################################################################
  elseif n == 5 # ARK 324
    A = [0 0 0 0 ; 1767732205903/2027836641118 0 0 0 ; 
         5535828885825/10492691773637 788022342437/10882634858940 0 0 ; 
         6485989280629/16251701735622                       -4246266847089/9704473918619  10755448449292/10357097424841 0];
    b = [  1471266399579/7840856788654
         -4482444167858/7529755066697
         11266239266428/11593286722821
	 1767732205903/4055673282236];
    bhat = b;
    c = A*ones(4,1); chat = c;
    Ahat = [0 0 0 0 ; 1767732205903/4055673282236 1767732205903/4055673282236 0 0 ;
   2746238789719/10658868560708 -640167445237/6845629431997      1767732205903/4055673282236 0 ; 
1471266399579/7840856788654 -4482444167858/7529755066697         11266239266428/11593286722821 1767732205903/4055673282236];
    r = 4;
##################################################################################
  elseif n == 6 # ARK 346
    r = 6;
    Ahat = [ 0 0 0 0 0 0 ; 
             1/4  1/4 0 0 0 0 ; 
             8611/62500 -1743/31250 1/4 0 0 0 
             5012029/34652500 -654441/2922500 174375/388108 1/4 0 0 ; 
             15267082809/155376265600 -71443401/120774400 730878875/902184768                          2285395/8070912 1/4 0; 
             82889/524892 0 15625/83664 69875/102672 -2260/8211 1/4];
    bhat = [ 82889/524892 0 15625/83664 69875/102672 -2260/8211 1/4]';
    A = [ 0 0 0 0 0 0 ; 
          1/2 0 0 0 0 0 ; 
          13861/62500 6889/62500 0 0 0 0 ; 
          -116923316275/2393684061468 -2731218467317/15368042101831                          9408046702089/11113171139209 0 0 0 ; -451086348788/2902428689909 -2682348792572/7519795681897            12662868775082/11960479115383 3355817975965/11060851509271 0 0;
      647845179188/3216320057751 73281519250/8382639484533                        552539513391/3454668386233 3354512671639/8306763924573 4040/17871 0];
    b = bhat;
    c = A*ones(r,1); chat = Ahat*ones(r,1);
##################################################################################
################################ IMKG methods ####################################
##################################################################################
  elseif n == 7 # IMKG232a
    r = 4; a1 = 1/2; a2 = 1/2; a3 = 1;
    A = [ 0 0 0 0 ; a1 0 0 0 ; 0 a2 0 0 ; 0 0 a3 0];
    b = [0 0 a3 0]';
    dhat3 = 0;
    ahat3 = 1;
    dhat2 = 0.5*(2-sqrt(2));
    dhat1 = dhat2;
    ahat2 = (sqrt(2)-1)/2;
    ahat1 = 0;
    Ahat = [0 0 0 0 ; ahat1 dhat1 0 0 ; 0 ahat2 dhat2 0 ; 0 0 ahat3 dhat3];
    bhat = [0 0 ahat3 dhat3]';     
    c = A*ones(r); chat = Ahat*ones(r); 
#################################################################################
  elseif n == 8 # IMKG232b
    r = 4; a1 = 1/2; a2 = 1/2; a3 = 1;
    A = [ 0 0 0 0 ; a1 0 0 0 ; 0 a2 0 0 ; 0 0 a3 0];
    b = [0 0 a3 0]';
    dhat3 = 0;
    ahat3 = 1;
    dhat2 = 0.5*(2+sqrt(2));
    dhat1 = dhat2;
    ahat2 = -(1+sqrt(2))/2
    ahat1 = 0;
    Ahat = [0 0 0 0 ; ahat1 dhat1 0 0 ; 0 ahat2 dhat2 0 ; 0 0 ahat3 dhat3];
    bhat = [0 0 ahat3 dhat3]';     
    c = A*ones(r); chat = Ahat*ones(r);     
##################################################################################
  elseif n == 9 # IMKG242a
    r = 5; a1 = 0.25; a2 = 1/3; a3 = 0.5; a4 = 1.0; 
    ahat4 = 1;
    ahat1 = 0;
    dhat1 = 0;
    dhat3 = -1/2; 
    dhat2 = (0.5-dhat3)/(1-dhat3); 
    ahat2 = 2*dhat1 - 2*dhat1*dhat2; ahat3 = 0.5-dhat3;
    A = [0 0 0 0 0 ; a1 0 0 0 0 ; 0 a2 0 0 0 ; 0 0 a3 0 0 ; 0 0 0 a4 0 ];
    b = [0 0 0 a4 0]';
    Ahat = [0 0 0 0 0 ; ahat1 dhat1 0 0 0 ; 0 ahat2 dhat2 0 0 ; 0 0 ahat3 dhat3 0 ; 0 0 0 ahat4 0];
    bhat = [0 0 0 ahat4 0]';
    c = A*ones(r); chat = Ahat*ones(r);
##################################################################################
  elseif n == 10 # IMKG242b
    r = 5; a1 = 0.25; a2 = 1/3; a3 = 0.5; a4 = 1.0; 
    ahat4 = 1;
    ahat1 = 0;
    dhat1 = 0;
    dhat1 = 0;
    dhat3 = 2/3 ; #0.5*(2+sqrt(2)); 
    dhat2 = (0.5-dhat3)/(1-dhat3); 
    ahat2 = 2*dhat1 - 2*dhat1*dhat2; ahat3 = 0.5-dhat3;
    A = [0 0 0 0 0 ; a1 0 0 0 0 ; 0 a2 0 0 0 ; 0 0 a3 0 0 ; 0 0 0 a4 0 ];
    b = [0 0 0 a4 0]';
    Ahat = [0 0 0 0 0 ; ahat1 dhat1 0 0 0 ; 0 ahat2 dhat2 0 0 ; 0 0 ahat3 dhat3 0 ; 0 0 0 ahat4 0];
    bhat = [0 0 0 ahat4 0]';
    c = A*ones(r); chat = Ahat*ones(r);
##################################################################################
  elseif n == 11 # IMKG243a
    r = 5; a1 = 0.25; a2 = 1/3; a3 = 0.5; a4 = 1.0; 
    ahat4 = 1;
    ahat1 = 0;
    dhat2 = 0.5*(1+sqrt(3)/3);
    dhat3 = dhat2;
    ahat3 = 1/2-dhat3;
    dhat1 = (ahat3-dhat2+dhat2*dhat3)/(1-dhat2-dhat3);
    ahat2 = (dhat1-dhat1*dhat3-dhat1*dhat2+dhat1*dhat2*dhat3)/(1-dhat3);
    A = [0 0 0 0 0 ; a1 0 0 0 0 ; 0 a2 0 0 0 ; 0 0 a3 0 0 ; 0 0 0 a4 0 ];
    b = [0 0 0 a4 0]';
    Ahat = [0 0 0 0 0 ; ahat1 dhat1 0 0 0 ; 0 ahat2 dhat2 0 0 ; 0 0 ahat3 dhat3 0 ; 0 0 0 ahat4 0];
    bhat = [0 0 0 ahat4 0]';
    c = A*ones(r); chat = Ahat*ones(r);
##################################################################################
  elseif n == 12 # IMKG252a
      r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
      A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
      c = A*ones(6,1); b = [0 0 0 0 a5 0]';
      ahat1 = 0;
      ahat5 = 1;
      dhat1 = 0;
      dhat2 = 0;
      dhat4 = 0.5*(2-sqrt(2)) ; 
      ahat4 = 1/2-dhat4;
      dhat3 = (ahat4*ahat5 - ahat5*dhat1 - ahat5*dhat2 + dhat1*dhat2+ dhat1*dhat4 + dhat2*dhat4)/(ahat5-dhat1-dhat2-dhat4);
      ahat3 = 0; 
      ahat2 = 0;
      Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
      chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 13 # IMKG252b
      r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
      A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
      c = A*ones(6,1); b = [0 0 0 0 a5 0]';
      ahat1 = 0;
      ahat5 = 1;
      dhat1 = 0;
      dhat2 = 0;
      dhat4 = -1 # 0.5*(2+sqrt(2)) ; 
      ahat4 = 1/2-dhat4;
      dhat3 = (ahat4*ahat5 - ahat5*dhat1 - ahat5*dhat2 + dhat1*dhat2+ dhat1*dhat4 + dhat2*dhat4)/(ahat5-dhat1-dhat2-dhat4);
      ahat3 = 0; 
      ahat2 = 0;
      Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
      chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 14 # IMKG253a
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat1 = 0;
    dhat4 = 0.5*(1-sqrt(3)/3); 
    dhat3 = dhat4;
    ahat4 = 1/2-dhat4;
    dhat2= (ahat4*ahat5 - ahat5*dhat1 - ahat5*dhat3 + dhat1*dhat3+ dhat1*dhat4 + dhat3*dhat4)/(ahat5-dhat1-dhat3-dhat4);
    ahat3 = (-ahat4*ahat5*dhat2+ahat5*dhat2*dhat3- dhat2*dhat3*dhat4)/(-ahat4*ahat5);
    ahat2 = 0;
    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 15 # IMKG253b
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat1 = 0;
    dhat4 = 0.5*(1+sqrt(3)/3); 
    dhat3 = dhat4;
    ahat4 = 1/2-dhat4;
    dhat2= (ahat4*ahat5 - ahat5*dhat1 - ahat5*dhat3 + dhat1*dhat3+ dhat1*dhat4 + dhat3*dhat4)/(ahat5-dhat1-dhat3-dhat4);
    ahat3 = (-ahat4*ahat5*dhat2+ahat5*dhat2*dhat3- dhat2*dhat3*dhat4)/(-ahat4*ahat5);
    ahat2 = 0;
    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 16 # IMKG254a
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat4 = 3/2;
    dhat3 = 1/2;
    dhat2 = 1/2;
    ahat4 = 1/2-dhat4;
    dhat1= (ahat4*ahat5 - ahat5*dhat3 - ahat5*dhat2 + dhat3*dhat2+ dhat3*dhat4 + dhat2*dhat4)/(ahat5-dhat3-dhat2-dhat4);
    ahat3 = (- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2+ ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3- dhat1*dhat2*dhat3 -dhat1*dhat2*dhat4 - dhat1*dhat3*dhat4- dhat2*dhat3*dhat4)/(-ahat4*ahat5)
    ahat2 = ( - ahat3*ahat4*ahat5*dhat1 + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3 + dhat1*dhat2*dhat3*dhat4)/(-ahat3*ahat4*ahat5)
    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 17 # IMKG254b
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat4 = 1;
    dhat3 = 1;
    dhat2 = 1;
    ahat4 = 1/2-dhat4;
    dhat1= (ahat4*ahat5 - ahat5*dhat3 - ahat5*dhat2 + dhat3*dhat2+ dhat3*dhat4 + dhat2*dhat4)/(ahat5-dhat3-dhat2-dhat4);
    ahat3 = (- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2+ ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3- dhat1*dhat2*dhat3 -dhat1*dhat2*dhat4 - dhat1*dhat3*dhat4- dhat2*dhat3*dhat4)/(-ahat4*ahat5)
    ahat2 = ( - ahat3*ahat4*ahat5*dhat1 + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3 + dhat1*dhat2*dhat3*dhat4)/(-ahat3*ahat4*ahat5)
    ahat2 = ( - ahat3*ahat4*ahat5*dhat1 + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3 + dhat1*dhat2*dhat3*dhat4)/(-ahat3*ahat4*ahat5)
    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 19 # IMKG254d
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat4 = 2;
    dhat3 = 1;
    dhat2 = 1;
    ahat4 = 1/2-dhat4;
    dhat1= (ahat4*ahat5 - ahat5*dhat3 - ahat5*dhat2 + dhat3*dhat2+ dhat3*dhat4 + dhat2*dhat4)/(ahat5-dhat3-dhat2-dhat4);
    ahat3 = (- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2+ ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3- dhat1*dhat2*dhat3 -dhat1*dhat2*dhat4 - dhat1*dhat3*dhat4- dhat2*dhat3*dhat4)/(-ahat4*ahat5)
    ahat2 = ( - ahat3*ahat4*ahat5*dhat1 + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3 + dhat1*dhat2*dhat3*dhat4)/(-ahat3*ahat4*ahat5)
    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
  elseif n == 18 # IMKG254c
    r = 6; a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    A = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0];
    c = A*ones(6,1); b = [0 0 0 0 a5 0]';
    ahat1 = 0;
    ahat5 = 1;
    dhat4 = 1/6;
    dhat3 = 1/6;
    dhat2 = 1/6;
    ahat4 = 1/2-dhat4;
    dhat1= (ahat4*ahat5 - ahat5*dhat3 - ahat5*dhat2 + dhat3*dhat2+ dhat3*dhat4 + dhat2*dhat4)/(ahat5-dhat3-dhat2-dhat4);
    ahat3 = (- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2+ ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3- dhat1*dhat2*dhat3 -dhat1*dhat2*dhat4 - dhat1*dhat3*dhat4- dhat2*dhat3*dhat4)/(-ahat4*ahat5)
    ahat2 = ( - ahat3*ahat4*ahat5*dhat1 + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3 + dhat1*dhat2*dhat3*dhat4)/(-ahat3*ahat4*ahat5)

    Ahat = [ 0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; 0 0 0 0 ahat5 0];
    chat = Ahat*ones(6,1); bhat = [0 0 0 0 ahat5 0]';
##################################################################################
  elseif n == 20 # IMKG342a
    a4 = 3/4; ahat4 = 3/4; bhat3 = 1/4; b3 = 1/4;
    dhat3 = (1+sqrt(3)/3)/2;
    dhat2 = (1+sqrt(3)/3)/2;
    a2    = 2/3;  
    b1 = 2/3-a2;
    dhat1 = 0;
    ahat2 = a2-dhat2;
    bhat1 = (-ahat2-dhat2+b1+a2); 
    ahat3 = (2/9-2*dhat3/3)/(ahat2+dhat2+bhat1);
    bhat2 = 2/3 - dhat3 - ahat3;
    a3    = (2/9)/(a2+b1);
    b2    = 2/3 - a3;
    ahat1 = 0;
    Ahat = [0 0 0 0 0 ; ahat1 dhat1 0 0 0 ; bhat1 ahat2 dhat2 0 0 ; bhat2 0 ahat3 dhat3 0 ; bhat3 0 0 ahat4 0];
    bhat = [bhat3 ; 0 ; 0 ; ahat4 ; 0];
    chat = Ahat*ones(5,1);
    a1 = (1/24)/(a2*a3*a4);
    A = [0 0 0 0 0 ; a1 0 0 0 0 ; b1 a2 0 0 0; b2 0 a3 0 0 ; b3 0 0 a4 0];
    b = [b3 ; 0; 0 ; a4 ; 0]
    c = A*ones(5,1);     
    r = 5;
##################################################################################
  elseif n == 21 # IMKG343a
    a4 = 3/4; ahat4 = 3/4; bhat3 = 1/4; b3 = 1/4;
    dhat3 = 1;
    dhat2 = 1;
    a2    = 2/3;  
    b1    = 2/3-a2;
    ahat2 = a2-dhat2;
    bhat1 = (-ahat2-dhat2+b1+a2); 
    a3    = (2/9)/(a2+b1);
    b2    =  2/3 - a3;
   ahat3 = (2/9-2*dhat3/3)/(ahat2+dhat2+bhat1);
   #ahat3 = -100;
    bhat2 = 2/3 - dhat3 - ahat3;
    dhat1 =  -(ahat2*ahat3*ahat4  + ahat3*ahat4*bhat1  - ahat4*bhat2*dhat2 + bhat3*dhat2*dhat3)/(- ahat3*ahat4 - ahat4*bhat2+ ahat4*dhat2 + bhat3*dhat2 + bhat3*dhat3- dhat2*dhat3)
    ahat1 = -( - ahat3*ahat4*bhat1*dhat1+ ahat4*bhat2*dhat1*dhat2- bhat3*dhat1*dhat2*dhat3)/(ahat2*ahat3*ahat4)
   # ahat1 = 0;
    Ahat = [0 0 0 0 0 ; ahat1 dhat1 0 0 0 ; bhat1 ahat2 dhat2 0 0 ; bhat2 0 ahat3 dhat3 0 ; bhat3 0 0 ahat4 0];
    bhat = [bhat3 ; 0 ; 0 ; ahat4 ; 0];
    chat = Ahat*ones(5,1);
    a1 = (1/24)/(a2*a3*a4);
    A = [0 0 0 0 0 ; a1 0 0 0 0 ; b1 a2 0 0 0; b2 0 a3 0 0 ; b3 0 0 a4 0];

  #  A = [0 0 0 0 0 ; 0.25 0 0 0 0 ; 0 1/3 0 0 0 ; 0 0 2/3 0 0 ; 1/4 0 0 3/4 0];
    b = [b3 ; 0; 0 ; a4 ; 0];
    c = A*ones(5,1);      
    r = 5;
##################################################################################
  elseif n == 22 # IMKG353a
    a5 = 3/4; b4 = 1/4; ahat5 = 3/4; bhat4 = 1/4; a3 = 2/3;
    b1 = 0; bhat2 = 0;
    bhat1 = b1; b2 = bhat2; 
    dhat1 = 0; 
    dhat4 = 1;
    dhat3 = 1;

    ahat3 = a3-dhat4;   

    b2 = ahat3+dhat3 + bhat2-a3;
    a4    = (2/9)/(a3+b2);
    ahat4 = (2/9-2*dhat4/3)/(ahat3+dhat3+bhat2);
    bhat3 = 2/3 - dhat4 - ahat4;
    b3 = 2/3-a4;
    a2 = (1/30-a3*a4*a5*b1)/(a3*a4*a5);
    a1 = 1/(150*a2*a3*a4*a5);

   dhat2 = -(ahat3*ahat4*ahat5 + ahat4*ahat5*bhat2 + bhat4*dhat3*dhat4 - ahat5*bhat3*dhat3)/(- ahat4*ahat5  - ahat5*bhat3 + ahat5*dhat3+ bhat4*dhat3 + bhat4*dhat4  - dhat3*dhat4)
  ahat2 = 0; ahat1 = 0;
  # use the following definitions of ahat1 and ahat2 in general case, ahat2 = 0 = ahat1 is fine .
  #  ahat2 = -(ahat3*ahat4*ahat5*bhat1 - ahat3*ahat4*ahat5*dhat1 - ahat4*ahat5*bhat2*dhat1 - ahat4*ahat5*bhat2*dhat2 + ahat4*ahat5*dhat1*dhat2 + ahat5*bhat3*dhat1*dhat2 + ahat5*bhat3*dhat1*dhat3+ ahat5*bhat3*dhat2*dhat3- ahat5*dhat1*dhat2*dhat3 - bhat4*dhat1*dhat2*dhat3 - bhat4*dhat1*dhat2*dhat4 - bhat4*dhat1*dhat3*dhat4 - bhat4*dhat2*dhat3*dhat4 + dhat1*dhat2*dhat3*dhat4)/(ahat3*ahat4*ahat5)    
  #  ahat1 = -(- ahat3*ahat4*ahat5*bhat1*dhat1+ ahat4*ahat5*bhat2*dhat1*dhat2 - ahat5*bhat3*dhat1*dhat2*dhat3+ bhat4*dhat1*dhat2*dhat3*dhat4)/(ahat2*ahat3*ahat4*ahat5 )
    A = [ 0 0 0 0 0 0; a1 0 0 0 0 0; b1 a2 0 0 0 0; b2 0 a3 0 0 0;  b3 0 0 a4 0 0 ; b4 0 0 0 a5 0];
    b = [b4 0 0 0 a5 0 ]';
    c = A*ones(6,1); r = 6;
    Ahat = [ 0 0 0 0 0 0; ahat1 dhat1 0 0 0 0; bhat1 ahat2 dhat2 0 0 0; bhat2 0 ahat3 dhat3 0 0;  bhat3 0 0 ahat4 dhat4 0 ; bhat4 0 0 0 ahat5 0 ];
    bhat = [bhat4 0 0 0 ahat5 0 ]';
    chat = Ahat*ones(6,1);
    r = 6;
##################################################################################
  elseif n == 23 # IMKG354a
    a5 = 3/4; b4 = 1/4; ahat5 = 3/4; bhat4 = 1/4;
    b1 = 1; bhat1 = b1; b2 = -1; bhat2 = b2;
    dhat4 = 1; 
    dhat3 = 2/5;
    dhat2 = 2/5;
    a3 =5/3;
    ahat3 = a3-dhat4;  
    ahat3 = b2-dhat3-bhat2+a3;
    b2 = ahat3+dhat3 + bhat2-a3;
    a4    = (2/9)/(a3+b2);
    ahat4 = (2/9-2*dhat4/3)/(ahat3+dhat3+bhat2);
    bhat3 = 2/3 - dhat4 - ahat4;
    b3 = 2/3-a4;
    a2 = (1/30-a3*a4*a5*b1)/(a3*a4*a5);
    a1 = 1/(150*a2*a3*a4*a5);
    dhat1 = -(ahat3*ahat4*ahat5 + ahat4*ahat5*bhat2  - ahat4*ahat5*dhat2  - ahat5*bhat3*dhat2 - ahat5*bhat3*dhat3+ ahat5*dhat2*dhat3+ bhat4*dhat2*dhat3 + bhat4*dhat2*dhat4  + bhat4*dhat3*dhat4 - dhat2*dhat3*dhat4)/(-ahat4*ahat5-ahat5*bhat3+ ahat5*dhat2 + ahat5*dhat3+ bhat4*dhat2+ bhat4*dhat3 + bhat4*dhat4-dhat2*dhat3 - dhat2*dhat4-dhat3*dhat4 )
    ahat2 = -(ahat3*ahat4*ahat5*bhat1 - ahat3*ahat4*ahat5*dhat1 - ahat4*ahat5*bhat2*dhat1 - ahat4*ahat5*bhat2*dhat2 + ahat4*ahat5*dhat1*dhat2 + ahat5*bhat3*dhat1*dhat2 + ahat5*bhat3*dhat1*dhat3+ ahat5*bhat3*dhat2*dhat3- ahat5*dhat1*dhat2*dhat3 - bhat4*dhat1*dhat2*dhat3 - bhat4*dhat1*dhat2*dhat4 - bhat4*dhat1*dhat3*dhat4 - bhat4*dhat2*dhat3*dhat4 + dhat1*dhat2*dhat3*dhat4)/(ahat3*ahat4*ahat5)    
    ahat1 = -(- ahat3*ahat4*ahat5*bhat1*dhat1+ ahat4*ahat5*bhat2*dhat1*dhat2 - ahat5*bhat3*dhat1*dhat2*dhat3+ bhat4*dhat1*dhat2*dhat3*dhat4)/(ahat2*ahat3*ahat4*ahat5 )
    A = [ 0 0 0 0 0 0; a1 0 0 0 0 0; b1 a2 0 0 0 0; b2 0 a3 0 0 0;  b3 0 0 a4 0 0 ; b4 0 0 0 a5 0];
    b = [b4 0 0 0 a5 0 ]';
    c = A*ones(6,1); r = 6;
    Ahat = [ 0 0 0 0 0 0; ahat1 dhat1 0 0 0 0; bhat1 ahat2 dhat2 0 0 0; bhat2 0 ahat3 dhat3 0 0;  bhat3 0 0 ahat4 dhat4 0 ; bhat4 0 0 0 ahat5 0 ];
    bhat = [bhat4 0 0 0 ahat5 0 ]';
    chat = Ahat*ones(6,1);
    r = 6;
##############################################################################3
  elseif n == 24 
   # these coefficients produce a reasonable first order method
   # a3 = 1;
   # b1 = 1;
   # a2 = 1/2-b1;
   # a1 = 1/(4*b1);    
   # dhat2 = 1;
   # aphat = 0.25;


    a3 = 1;
    b1 = 1;
    a2 = 1/2-b1;
    a1 = 1/(4*b1);
  
    dhat2 = 1;
    aphat = 2;

    ahat2 = dhat2;
    dhat1 = dhat2;
    betahat = (ahat2+dhat1*dhat2 - aphat *( dhat2+ahat2))/(ahat2+dhat1);


    ahat3 = 1-aphat - betahat;
   # dhat1 = (1/2-betahat *dhat2 - ahat2 *ahat3)/aphat;

    A = [0 0 0 0 0; a1 0 0 0 0; 0 0 0 0 0; 0 b1 a2 0 0 ; 0 0 0 a3 0 ];
    b = [0 0 0 a3 0 ]';
    Ahat = [0 0 0 0 0; 0 dhat1 0 0 0 ; 0 0 dhat2 0 0 ; 0 0 ahat2 0 0 ; 0 aphat betahat ahat3 0];
    bhat = [0 aphat betahat ahat3 0 ]';
    c = A*ones(5,1); chat = A*ones(5,1); r = 5;   
################################################################################
  elseif n == 25

    # Conditions for 2nd order:
    # Need ahat5 ( ahat4 + dhat4) + dhat5 = 1/2 and a5 (ahat4+dhat4) = 1/2
    # these are OK
    dhat5 = 3/4; a5 = .75; dhat4 = .7;
    dhat3 = .75; 
    dhat2 = dhat3;

#    c = 3
#    dhat5 = c; a5 = 2/3; dhat4 = c;
#    dhat3 = c; 
#    dhat2 = -1;

#    c = 3;
#    dhat5 = c; a5 = 1; dhat4 = c;
#    dhat3 = c; 
#    dhat2 = c;

#    c = 3;
#    dhat5 = c; a5 = .8; dhat4 = c;
#    dhat3 = .1; 
#    dhat2 = -.8;

#    dhat5 = 3;
#    dhat4 = 3;
#    dhat3 = -.75;
#    dhat2 = .2;
#    a5    = 1;


    ahat4 = 1/(2*a5) - dhat4;
    ahat5 = (1/2-dhat5)/(ahat4+dhat4);
    ap = 1-a5; aphat = 1-ahat5-dhat5;


#   - ahat5*dhat1  - aphat*dhat1 + dhat1*dhat2  + dhat1*dhat3 + dhat1*dhat4 + ahat4*ahat5   - ahat5*dhat2 - ahat5*dhat3   - aphat*dhat2  - aphat*dhat3 - aphat*dhat4  + dhat2*dhat3 + dhat2*dhat4 + dhat3*dhat4 = 0
   dhat1 = -(ahat4*ahat5   - ahat5*dhat2 - ahat5*dhat3   - aphat*dhat2  - aphat*dhat3 - aphat*dhat4  + dhat2*dhat3 + dhat2*dhat4 + dhat3*dhat4)/(- ahat5  - aphat + dhat2  + dhat3 + dhat4)

   println( ahat5  + aphat  - dhat1 - dhat2 - dhat3 - dhat4)

# + ahat3*ahat4*ahat5- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2 + ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3 + aphat*dhat1*dhat2+ aphat*dhat1*dhat3 + aphat*dhat1*dhat4 + aphat*dhat2*dhat3 + aphat*dhat2*dhat4+ aphat*dhat3*dhat4- dhat1*dhat2*dhat3 - dhat1*dhat2*dhat4- dhat1*dhat3*dhat4- dhat2*dhat3*dhat4 = 0
   ahat3 = -(- ahat4*ahat5*dhat1 - ahat4*ahat5*dhat2 + ahat5*dhat1*dhat2 + ahat5*dhat1*dhat3 + ahat5*dhat2*dhat3 + aphat*dhat1*dhat2+ aphat*dhat1*dhat3 + aphat*dhat1*dhat4 + aphat*dhat2*dhat3 + aphat*dhat2*dhat4+ aphat*dhat3*dhat4- dhat1*dhat2*dhat3 - dhat1*dhat2*dhat4- dhat1*dhat3*dhat4- dhat2*dhat3*dhat4 )/(ahat4*ahat5);

# ahat2*ahat3*ahat4*ahat5 - ahat3*ahat4*ahat5*dhat1  + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3- aphat*dhat1*dhat2*dhat3 - aphat*dhat1*dhat2*dhat4 - aphat*dhat1*dhat3*dhat4 - aphat*dhat2*dhat3*dhat4 + dhat1*dhat2*dhat3*dhat4 = 0
    ahat2 = -(- ahat3*ahat4*ahat5*dhat1  + ahat4*ahat5*dhat1*dhat2 - ahat5*dhat1*dhat2*dhat3- aphat*dhat1*dhat2*dhat3 - aphat*dhat1*dhat2*dhat4 - aphat*dhat1*dhat3*dhat4 - aphat*dhat2*dhat3*dhat4 + dhat1*dhat2*dhat3*dhat4)/(ahat3*ahat4*ahat5);

    # ahat1*ahat2*ahat3*ahat4*ahat5+ aphat*dhat1*dhat2*dhat3*dhat4  = 0
    ahat1 = - aphat*dhat1*dhat2*dhat3*dhat4  / (ahat2*ahat3*ahat4*ahat5);
   
    ap = 1-a5;
    a4 = 1/(2*a5);  a3 = 3/(16*a4*a5); a2 = 1/(32*a3*a4*a5); a1 = 1/(128*a2*a3*a4*a5);
   

    A    = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; ap 0 0 0 a5 0 ]
    Ahat = [0 0 0 0 0 0 ; ahat1 dhat1 0 0 0 0 ; 0 ahat2 dhat2 0 0 0 ; 0 0 ahat3 dhat3 0 0 ; 0 0 0 ahat4 dhat4 0 ; aphat 0 0 0 ahat5 dhat5 ];
    c = A*ones(6,1); chat = Ahat*ones(6,1); 
    b = [ap 0 0 0 a5 0 ]'; bhat = [aphat 0 0 0 ahat5 dhat5]';
    r = 6;
##########################################################################################
  elseif n == 26 # S5 on confluence
    e = 1/14;
    a1 = 1/4; a2 = 1/3; a3 = 1/2; a4 = 1;
    
    A    = [0 0 0 0 0 ; a1 0 0 0 0 ; 0 a2 0 0 0 ; 0 0 a3 0 0 ; 0 0 0 a4 0];
    Ahat = [0 0 0 0 0 ; 0 a1 0 0 0 ; 0 0 a2 0 0 ; 0 0 0 a3 0 ; 1/2-3*e 4*e 0 0 1/2-e ];
    c = A*ones(5,1); chat = Ahat*ones(5,1); 
    b = [0 0 0 a4 0 ]'; bhat = [1/2-3*e 4*e 0 0 1/2-e]';
    r = 5;   
#############################################################################################
  elseif n == 27 # S4 on confluence
    e = 1/22;
    a1 = 1/4; a2 = 1/6; a3 = 3/8; a4 = 1/2; a5 = 1;
    
    A    = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; 0 0 0 0 a5 0 ]
    Ahat = [0 0 0 0 0 0 ; 0 a1 0 0 0 0 ; 0 0 a2 0 0 0 ; 0 0 0 a3 0 0 ; 0 0 0 0 a4 0 ; 1/2-4*e 5*e 0 0 0 1/2-e ];
    c = A*ones(6,1); chat = Ahat*ones(6,1); 
    b = [0 0 0 0 a5 0 ]'; bhat = [1/2-4*e 5*e 0 0 0 1/2-e]';
    r = 6;   ##########################################################################################
  elseif n == 28 # S53 on confluence
    e = 1/18;
    a1 = 1/5; a2 = 1/5; a3 = 1/3; a4 = 2/3; a5 = 3/4; ap=1/4;
    A    = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; ap 0 0 0 a5 0 ]
    Ahat = [0 0 0 0 0 0 ; 0 a1 0 0 0 0 ; 0 0 a2 0 0 0 ; 0 0 0 a3 0 0 ; 0 0 0 0 a4 0 ; 1/2-4*e 5*e 0 0 0 1/2-e ];
    c = A*ones(6,1); chat = Ahat*ones(6,1); 
    b = [ap 0 0 0 a5 0 ]'; bhat = [1/2-4*e 5*e 0 0 0 1/2-e]';
    r = 6;   
##########################################################################################
  elseif n == 29 # S54 on confluence
    e = 1/18;
    a1 = 1/5; a2 = 1/5; a3 = 1/3; a4 = 2/3; a5 = 3/4; ap=1/4;
    A    = [0 0 0 0 0 0 ; a1 0 0 0 0 0 ; 0 a2 0 0 0 0 ; 0 0 a3 0 0 0 ; 0 0 0 a4 0 0 ; ap 0 0 0 a5 0 ]
    Ahat = [0 0 0 0 0 0 ; 0 a1 0 0 0 0 ; 0 0 a2 0 0 0 ; 0 0 0 a3 0 0 ; 1/3 0 0 0 1/3 0 ; 1/2-4*e 5*e 0 0 0 1/2-e ];
    c = A*ones(6,1); chat = Ahat*ones(6,1); 
    b = [ap 0 0 0 a5 0 ]'; bhat = [1/2-4*e 5*e 0 0 0 1/2-e]';
    r = 6;   
###################################################3
  elseif n == 30 # strangcarryover
    A = [0 0 0 0 0 0 ; 0 0 0 0 0 0 ; 0 1 0 0 0 0 ; 0 1/4 1/4 0 0 0 ; 0 1/6 1/6 2/3 0 0 ; 
         0 1/6 1/6 2/3 0 0];
    b = [0 1/6 1/6 2/3 0 0 ]';
    c = A*ones(6,1);
    r = 6;
    Ahat = [0 0 0 0 0 0 ; 1/2 0 0 0 0 0 ; 1/2 0 0 0 0 0 ; 1/2 0 0 0 0 0 ; 1/2 0 0 0 0 0 ; 1/2 0 0 0 0 1/2];
    bhat = [1/2 0 0 0 0 1/2]'; chat = Ahat*ones(6,1); 
###################################################
  elseif n == 31 # IMKG2-266
    r = 7;
    a1 = 1/6; a2 = 2/15; a3 = 1/4; a4 = 1/3; a5 = 1/2; a6 = 1; ap=0;
    e = 0.5/(2/a1-1)
    A    = [0 0 0 0 0 0 0; a1 0 0 0 0 0 0 ; 0 a2 0 0 0 0 0 ; 0 0 a3 0 0 0 0; 0 0 0 a4 0 0 0; ap 0 0 0 a5 0 0; 0 0 0 0 0 a6 0]
    Ahat = [0 0 0 0 0 0 0; 0 a1 0 0 0 0 0; 0 0 a2 0 0 0 0; 0 0 0 a3 0 0 0; 0 0 0 0 a4 0 0 ; 0 0 0 0 0 a5 0 ; 1/2+(1-1/a1)*e e/a1 0 0 0 0 1/2-e ];
    c = A*ones(7,1); chat = Ahat*ones(7,1); 
    b = [ap 0 0 0 0 a6 0 ]'; bhat = [1/2+(1-1/a1)*e e/a1 0 0 0 0 1/2-e]';
  end
  return A,Ahat,b,bhat,c,chat,r
end

