
using Pkg
using LinearAlgebra
using PyPlot
include("ETDRK.jl")

test1 = true;
test2 = true;

###########################################
##### Rudimentary test that    ############
##### phi_{l+1}(z) = (phi_l(z) - 1/l!)/z ##
###########################################
if test1 == true
  d = 5;
  z = 1;
  N = 10;
  err  = zeros(10,1);
  phil = exp(z);
  for l = 1:N
    global phil;
    (P,Q,tempR)  = ETDRK.etd_method_coefficient([z],1,1.0,l,d);
    phil   = (phil - 1/factorial(l-1))/z;
    err[l] = abs(tempR[1,1]-phil);
  end
  if norm(err,Inf) > 1e-10
    print("Test 1 fails with error = ")
    println(norm(err,Inf))
  else
    print("Test 1 passes with error = ")
    println(norm(err,Inf))
  end
end 

######################################################
#####  Test ETDRK reduces to RK if S = 0         #####
#####  should produce stability plot of          #####
#####  the underlying RK method                  #####
#####  which is stable on the real axis          #####
#####  out to -2                                 #####
######################################################
if test2 == true
  (A,b,c,numstages) = ETDRK.get_etdrk_method(1);
  N = 1im*[0 0 1; 0 0 0 ; 1 0 0 ];
  S = 1im*[0 0 0 ; 0 0 1 ; 0 1 0];

  function testeqn1d(x,y)
    R = ETDRK.getLWWstabfun(A,b,c,numstages,1.0,[x+1im*y],[0.0],1);
    R = abs(R[1,1]);
    # sorting regions into distinct numbers for easier plotting
    if R <= 1+1e-12
      return 1;
    else
      return 0;
    end
  end

  # The remaining part of the code plots the stability region
  # xlength = horizontal window size
  xlength = 6;
  # ylength = vertical window size
  ylength = 6;
  # xend, yend -  number of horizontal, vertical samples in the contour plot
  xend = 250;
  yend = 250;
  dx = xlength/xend;
  dy = ylength/yend;
  x = reshape(range(0,step=dx,length=xend),xend,1);
  y = reshape(range(0,step=dy,length = yend),yend,1);
  x = range(-xlength/2,step=dx,length = xend);
  y = range(-ylength/2,step=dy,length = yend);
  Z = zeros(xend,yend); Z2 = zeros(xend,yend);
  for i=1:xend
    for j=1:yend
      Z[i,j] = testeqn1d(x[i],y[j]);
    end
  end
  # plotting stability region
  PyPlot.figure()
  cp = plt.contourf(x, y, Z',levels=[.99,1]);
  PyPlot.show() 

  N  = 101;
  dt = 2/101;
  Rmax = 1;
  Rmin = 1.0
  for n = 1:N
    global Rmax,Rmin;
    x1 = -(n-1)*dt;
    x2 = -4 + (n-1)*dt
    Rmaxtemp = ETDRK.getLWWstabfun(A,b,c,numstages,1.0,[x1],[0.0],1);
    Rmintemp = ETDRK.getLWWstabfun(A,b,c,numstages,1.0,[x2],[0.0],1);
    if abs(Rmaxtemp[1,1]) > Rmax
      Rmax = abs(Rmaxtemp[1,1]);
    end
    if abs(Rmintemp[1,1]) < Rmin
      Rmin = abs(Rmintemp[1,1]);
    end
  end
  if Rmax > 1+1e-10 || Rmin < 1-1e-10
    print("Test 2 fails, underlying RK method has bug");
  else
    print("Test 2 passes");
  end
end

println("fin")
