module ETDRK

using Pkg
using LinearAlgebra

##########################################################
##### We use the approximation for the phi-functions #####
##### recommended in EXPINT - A Matlab Package for   #####
##### for exponential integrators ########################
########################################################## 

##############################################################
##### phipadecoeffe: computes the (d,d) Pade approximant #####
##### of phi_l(z) by returning the coefficients of the   #####
##### polynomials p,q where p/q \approx phi_l + O(z^{2d+1}) ##
##############################################################
function phipadecoeffs(l,d) 
  p = 1im*zeros(d+1,1); q = 1im*zeros(d+1,1);
  for i=0:d
    for j=0:i
      p[i+1] = p[i+1] + factorial(2*d+l-j)*(-1)^j / (factorial(j)*factorial(d-j)*factorial(l+i-j));
    end
    q[i+1] = q[i+1] + (-1)^i*factorial(2*d+l-i)/(factorial(i)*factorial(d-i));
  end
  p = factorial(d)*p/factorial(2*d+l);
  q = factorial(d)*q/factorial(2*d+l);
  return p,q
end

##############################################################
##### phipade computes R = P/Q for a given m x m array A #####
##### where P and Q are computing from the coefficients  #####
##### p,q computed with phipadecoeffs ########################
##############################################################
function etd_method_coefficient(A,m,coeff,l,d)
  (p,q) = phipadecoeffs(l,d);
  P = 1im*zeros(m,m); Q = 1im*zeros(m,m);
  for j=1:d+1
    P[:,:] = P[:,:] + p[j]*(A[:,:]^(j-1));
    Q[:,:] = Q[:,:] + q[j]*(A[:,:]^(j-1));
  end
  R = 1im*zeros(m,m);
  for j=1:m
    R[:,j] = Q\P[:,j];
  end
  return (P,Q,coeff*R)
end

########################################
##### EMC = ETD Method Coefficient #####
##### each ETD method coefficient  #####
##### is of the following form     #####
##### c1*phi_{l,m}(ck* something)  #####
########################################
struct EMC ### EMC = ETD Method Coefficient struct
  c1::Float64
  l::Int
  k::Int
end

######################################## ## New code added
##### EMC_LinComb = ETD Method Coefficient #####
##### each ETD method coefficient          #####
##### is a linear combination of the form  #####
##### c1*phi_{l,m}(ck* something)          #####
########################################
struct EMC_LinComb ### EMC = ETD Method Coefficient struct
  c1::AbstractVector{Float64}
  l::AbstractVector{Int}
  k::AbstractVector{Int}
end

#############################################################
##### Returns method coefficients of ETD method  ############
##### in the Ostermann form                    ##############
#############################################################
function get_etdrk_method(method)
  if method == 1
    c2  = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);

    b1  = EMC(1-1/(2*c2),1,0);
    b2  = EMC(1/(2*c2),1,0);
    
    A = [A11 A12 ; A21 A22];
    b = [b1 ; b2];
    c = [0 ; c2];
    numstages = 2;
  elseif method == 25
    c2 = 3/4;
    c4 = 1;
    println("c2 = c3 = ",c2)

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c2,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(0,1,0);
    A43 = EMC(1,1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;(1+c2)/(-c2);2/c2],[1,2,3],[4,4,4]);
    b2 = EMC_LinComb([1/c2;-1/(c2*c2)],[2,3],[4,4]);
    b3 = EMC_LinComb([1/(1-c2);(1-3*c2)/(c2*c2*(1-c2))],[2,3],[4,4]);
    b4 = EMC_LinComb([-c2/(1-c2);2/(1-c2)],[2,3],[4,4]);

    A = [A11 A12 A13 A14 ; A21 A22 A23 A24 ; A31 A32 A33 A34 ; A41 A42 A43 A44];
    b = [b1 ; b2 ; b3 ; b4];
    c = [0 ; c2 ; c2 ; c4];
    numstages = 4;
  elseif method == 26 #ETD-RK1-2-3b
    c2 = 3/4;
    c3 = 1;
    println("c2 = ",c2);

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(1,1,3);
    A33 = EMC(0,1,0);

    b1 = EMC(1,1,3);
    b2 = EMC(1/(c2-1),2,3);
    b3 = EMC(1/(1-c2),2,3);

    A = [A11 A12 A13 ; A21 A22 A23 ; A31 A32 A33];
    b = [b1 ; b2 ; b3];
    c = [0 ; c2 ; 1];
    numstages = 3;
  elseif method == 27 # ETD-RK2-3-4
    c2 = 1/3;
    c3 = 2/3; # c2<= c3
    println("c2 = ",c2, "; c3 = ",c3);
    c4 = 1;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC(c3*(2*c2-c3)/(2*c2),1,3);
    A32 = EMC(c3*c3/(2*c2),1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC((2*c3-1)/(2*c3),1,4);
    A42 = EMC(0,1,0);
    A43 = EMC(1/(2*c3),1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;(c3+1)/c3;2/c3],[1;2;3],[4;4;4]);
    b2 = EMC_LinComb([-1/(c3*(c3-1));2/(c3*(c3-1))],[2,3],[4,4]);
    b3 = EMC_LinComb([0],[1],[0]);
    b4 = EMC_LinComb([c3/(c3-1);2/(c3-1)],[2,3],[4,4]);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;
 
  elseif method == 28 # ETD-RK3-3-4
    c2 = 1/3;
    c3 = 3/4; # c2 != c3
    println("c2 = ",c2, "; c3 = ",c3);
    c4 = 1;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC(c3*(2*c2-c3)/(2*c2),1,3);
    A32 = EMC(c3*c3/(2*c2),1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC((2*c3-1)/(2*(c3-c2)),1,4);
    A43 = EMC((1-2*c2)/(2*(c3-c2)),1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;(c3+1)/c3;2/c3],[1;2;3],[4;4;4]);
    b2 = EMC_LinComb([-1/(c3*(c3-1));2/(c3*(c3-1))],[2,3],[4,4]);
    b3 = EMC_LinComb([0],[1],[0]);
    b4 = EMC_LinComb([c3/(c3-1);2/(c3-1)],[2,3],[4,4]);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;

  elseif method == 29 # ETD-RK1-3-4
    c2 = 1/5;
    c3 = 4/5; # can't have c2 = 1/3; c3 = 2/3;
    println("c2 = ",c2, "; c3 = ",c3);
    c4 = 1;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c3,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(0,1,0);
    A43 = EMC(1,1,4);
    A44 = EMC(0,1,0);

    b12co = (c2+c2*c2-c3*c3-c2^3)/(c2*(c2*c2-c2*c3-c2+c3*c3));
    b13co = (-4*c2*c3+3*c3*c3-c3+c2-c2*c2-c2*c3*c3+3*c2*c2*c3)/(c2*c3*(c2*c2-c2*c3-c2+c3*c3));
    b22co = (c3*c3-c2)/(c2*(c2*c2-c2*c3-c2+c3*c3));
    b23co = (2*c2-3*c3+1)/(c2*(c2*c2-c2*c3-c2+c3*c3));
    b32co = -c2/(c2*c2-c2*c3-c2+c3*c3);
    b33co = (2*c3+c2-1)/(c3*(c2*c2-c2*c3-c2+c3*c3));
    b42co = c2*c2/(c2*c2-c2*c3-c2+c3*c3);
    b43co = (c3-3*c2)/(c2*c2-c2*c3-c2+c3*c3);
#    println("b12co = ", b12co, "; b13co = ",b13co);
#    println("b22co = ", b22co, "; b23co = ",b23co);
#    println("b32co = ", b32co, "; b33co = ",b33co);
#    println("b42co = ", b42co, "; b43co = ",b43co);

    b1 = EMC_LinComb([1;b12co;b13co],[1,2,3],[4,4,4]);
    b2 = EMC_LinComb([b22co;b23co],[2,3],[4,4]);
    b3 = EMC_LinComb([b32co;b33co],[2,3],[4,4]);
    b4 = EMC_LinComb([b42co;b43co],[2,3],[4,4]);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;
  elseif method == 30 # ETD-RK1-2-4
    c2 = 1/4;
    c3 = 3/4; # c2 <= c3
    println("c2 = ",c2, "; c3 = ",c3);
    c4 = 1;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c3,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(0,1,0);
    A43 = EMC(1,1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[4,4]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(1,2,4);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;
  elseif method == 31 # ETD-RK1-2-5
    c2 = 1/4;
    c3 = 1/2;
    c4 = 3/4;
    c5 = 1;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c3,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(0,1,0);
    A43 = EMC(c4,1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC(0,1,0);
    A52 = EMC(0,1,0);
    A53 = EMC(0,1,0);
    A54 = EMC(1,1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(0,1,0);
    b5 = EMC(1,2,5);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;

  elseif method == 32 # ETD-RK1-2-3a
    c2 = 3/4;
    c3 = 1;
    println("c2 = ",c2);

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c3,1,3);
    A33 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[3,3]);
    b2 = EMC(0,1,0);
    b3 = EMC(1,2,3);

    A = [A11 A12 A13; A21 A22 A23; A31 A32 A33];
    b = [b1; b2; b3];
    c = [0; c2; c3];
    numstages = 3;

  elseif method == 33 # ETD-RK1-3-5
    c2 = 1/4;
    c3 = 1/2;
    c4 = 2/3;
    c5 = 1;
    println("c2 = ",c2, "; c3 = ",c3, "; c4 = ",c4);

    b52co = ((c4+c3)*(c4-c3))/(c3-c2-c3^2+c4*c3 -c4^2+c4*c2);
    b53co = (3*c3-2*c2-c4)/(c3-c2-c3^2+c4*c3-c4^2+c4*c2);
    b42co = -c3/(c4*(c4-c3)) - (1-c3)/(c4*(c4-c3))*b52co;
    b43co = 2/(c4*(c4-c3)) - (1-c3)/(c4*(c4-c3))*b53co;
    b32co = 1/c3 - c4/c3*b42co - 1/c3*b52co;
    b33co = -c4/c3*b43co - 1/c3*b53co;
    b12co = -b52co - b42co - b32co;
    b13co = -b53co - b43co - b33co;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC(0,1,0);
    A32 = EMC(c3,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(0,1,0);
    A43 = EMC(c4,1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC(0,1,0);
    A52 = EMC(0,1,0);
    A53 = EMC(0,1,0);
    A54 = EMC(1,1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;b12co;b13co],[1,2,3],[5,5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC_LinComb([b32co;b33co],[2,3],[5,5]);
    b4 = EMC_LinComb([b42co;b43co],[2,3],[5,5]);
    b5 = EMC_LinComb([b52co;b53co],[2,3],[5,5]);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;

  elseif method == 34 # ETD-RK2-2-3
    c2 = 3/4;
    c3 = 1;
    println("c2 = ",c2);
    a32 = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A31 = EMC((c3-a32),1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[3,3]);
    b2 = EMC(0,1,0);
    b3 = EMC(1,2,3);

    A = [A11 A12 A13; A21 A22 A23; A31 A32 A33];
    b = [b1; b2; b3];
    c = [0; c2; c3];
    numstages = 3;

  elseif method == 35 # ETD-RK2-2-4
    c2 = 1/2;
    c3 = 1/2;
    c4 = 1;
    a32 = 1/2;
    a43 = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC((c3-a32),1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC((c4-a43),1,4);
    A42 = EMC(0,1,0);
    A43 = EMC(a43,1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[4,4]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(1,2,4);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;

  elseif method == 36 # ETD-RK3-2-4
    c2 = 1/2;
    c3 = 1/2;
    c4 = 1;
    a32 = 1/2;
    a43 = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A31 = EMC((c3-a32),1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC((c4-a43),1,4);
    A43 = EMC(a43,1,4);
    A44 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[4,4]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(1,2,4);

    A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
    b = [b1; b2; b3; b4];
    c = [0; c2; c3; c4];
    numstages = 4;

  elseif method == 37 # ETD-RK3-2-5
    c2 = 1/2;
    c3 = 1/2;
    c4 = 1/2;
    c5 = 1;
    a32 = 1/2;
    a43 = 1/2;
    a54 = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC((c3-a32),1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC((c4-a43),1,4);
    A43 = EMC(a43,1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC(0,1,0);
    A52 = EMC(0,1,0);
    A53 = EMC((c5-a54),1,5);
    A54 = EMC(a54,1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(0,1,0);
    b5 = EMC(1,2,5);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;

  elseif method == 38 # ETD-RK2-2-5
    c2 = 1/2;
    c3 = 1/2;
    c4 = 1/2;
    c5 = 1;
    a32 = 1/2;
    a43 = 1/2;
    a54 = 1/2;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC((c3-a32),1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC((c4-a43),1,4);
    A42 = EMC(0,1,0);
    A43 = EMC(a43,1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC((c5-a54),1,5);
    A52 = EMC(0,1,0);
    A53 = EMC(0,1,0);
    A54 = EMC(a54,1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-1],[1,2],[5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC(0,1,0);
    b5 = EMC(1,2,5);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;

  elseif method == 39 # ETD-RK2-3-5
    c2 = 1/2;
    c3 = 1/2; # c2<= c3
    c4 = 1/2;
    println("c2 = ",c2, "; c3 = ",c3, "; c4 = ",c4);
    c5 = 1;
    a32 = 1/4;

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC(c3-a32,1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC(c4-(c4*c4/(2*c3)),1,4);
    A42 = EMC(0,1,0);
    A43 = EMC(c4*c4/(2*c3),1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC(c5-1/(2*c4),1,5);
    A52 = EMC(0,1,0);
    A53 = EMC(0,1,0);
    A54 = EMC(1/(2*c4),1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-(c4+1)/c4;2/c4],[1,2,3],[5,5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC_LinComb([1/(c4*(1-c4));-2/(c4*(1-c4))],[2,3],[5,5]);
    b5 = EMC_LinComb([-c4/(1-c4);2/(1-c4)],[2,3],[5,5]);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;
 
  elseif method == 40 # ETD-RK3-3-5
    c2 = 1/4;
    c3 = 1/2; # c2<= c3
    c4 = 2/3;
    println("c2 = ",c2, "; c3 = ",c3, "; c4 = ",c4);
    c5 = 1;
    a32 = 1/4;

    # the following are not free parameters
    a54 = (1-2*c3)/(2*(c4-c3));
    a43 = (c4*(c4-2*c2))/(2*(c3-c2));

    A11 = EMC(0,1,0);
    A12 = EMC(0,1,0);
    A13 = EMC(0,1,0);
    A14 = EMC(0,1,0);
    A15 = EMC(0,1,0);
    A21 = EMC(c2,1,2);
    A22 = EMC(0,1,0);
    A23 = EMC(0,1,0);
    A24 = EMC(0,1,0);
    A25 = EMC(0,1,0);
    A31 = EMC(c3-a32,1,3);
    A32 = EMC(a32,1,3);
    A33 = EMC(0,1,0);
    A34 = EMC(0,1,0);
    A35 = EMC(0,1,0);
    A41 = EMC(0,1,0);
    A42 = EMC(c4-a43,1,4);
    A43 = EMC(a43,1,4);
    A44 = EMC(0,1,0);
    A45 = EMC(0,1,0);
    A51 = EMC(0,1,0);
    A52 = EMC(0,1,0);
    A53 = EMC(c5-a54,1,5);
    A54 = EMC(a54,1,5);
    A55 = EMC(0,1,0);

    b1 = EMC_LinComb([1;-(c4+1)/c4;2/c4],[1,2,3],[5,5,5]);
    b2 = EMC(0,1,0);
    b3 = EMC(0,1,0);
    b4 = EMC_LinComb([1/(c4*(1-c4));-2/(c4*(1-c4))],[2,3],[5,5]);
    b5 = EMC_LinComb([-c4/(1-c4);2/(1-c4)],[2,3],[5,5]);

    A = [A11 A12 A13 A14 A15; A21 A22 A23 A24 A25; A31 A32 A33 A34 A35; A41 A42 A43 A44 A45; A51 A52 A53 A54 A55];
    b = [b1; b2; b3; b4; b5];
    c = [0; c2; c3; c4; c5];
    numstages = 5;
 

 end 
  return A,b,c,numstages;
end 


#############################################################
#### Returns Locke, Weller, Wood stability matrix R   #######
#### from the method coefficient arrays A,b,c and     #######
#### numstages, assumes underlying RK method          #######
#### is explicit                                      #######
#############################################################
function getLWWstabfun(A,b,c,numstages,dt,N,S,dim)
  R   = Matrix{Float64}(I,dim,dim);
  R   = R + 1im*zeros(dim,dim);
  (P,Q,temp) = etd_method_coefficient(dt*S,dim,1.0,0,5);
  R          = temp*R;
  U          = zeros(dim,dim,numstages)*1im;
  for j = 1:numstages
    (P,Q,chij) = etd_method_coefficient(dt*S,dim,1.0,0,5)
    U[:,:,j]     = chij*Matrix{Float64}(I,dim,dim);
    for k = 1:j-1
      EMCjk  = A[j,k];
      if EMCjk.k > 0
        (P,Q,Ajk) = etd_method_coefficient(dt*c[EMCjk.k]*S,dim,EMCjk.c1,EMCjk.l,5);
      else  ### the else probably never happens
        (P,Q,Ajk) = etd_method_coefficient(dt*S,dim,EMCjk.c1,EMCjk.l,5);
      end 
      U[:,:,j]     = U[:,:,j] + dt * Ajk * N[:,:] * U[:,:,k];
    end
    b_len = length(b[j].c1)  # New code added
    for ii = 1:b_len
      EMCk = b[j];
      (P,Q,bk) = etd_method_coefficient(dt*S,dim,EMCk.c1[ii],EMCk.l[ii],5);
      R[:,:]   = R[:,:] + dt * bk * N[:,:] * U[:,:,j];
    end
  end 
  return R;
end




end
