Last modified by Andrew J. Steyer on 24 March 2020.

This repository contains Julia code for creating and plotting stability diagrams for IMEX Runge-Kutta and ETD Runge-Kutta methods.

This code runs on Julia version 1.1, it requires the following packages to run: Pkg, LinearAlgebra, PyPlot.
